package com.ysa.training;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.ysa.model.NeuralNetworkConfig;
import com.ysa.util.DataLoader;
import com.ysa.util.DataLoader.SplitData;

import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.BackPropagation;
import org.neuroph.nnet.learning.MomentumBackpropagation;

public class NetworkTrainer {

    private NeuralNetworkConfig config = new NeuralNetworkConfig();

    /**
     * Ortak MSE hesaplama metodu (normalize çıkışlar için)
     */
    private double calculateMSE(MultiLayerPerceptron net, DataSet dataSet) {
        double sum = 0.0;
        int count = 0;

        for (DataSetRow row : dataSet.getRows()) {
            double[] input = row.getInput();
            double[] target = row.getDesiredOutput();

            net.setInput(input);
            net.calculate();
            double[] output = net.getOutput();

            for (int i = 0; i < output.length; i++) {
                double diff = target[i] - output[i];
                sum += diff * diff;
                count++;
            }
        }
        return sum / count;
    }

    /**
     * Menü 1: Ağı Eğit ve Test Et (Momentumlu)
     */
    public void trainAndTestWithMomentum() {
        try {
            SplitData split = DataLoader.loadAndSplit(0.75);
            DataSet trainSet = split.trainSet;
            DataSet testSet  = split.testSet;

            System.out.println("Train satir sayisi: " + trainSet.size());
            System.out.println("Test  satir sayisi: " + testSet.size());

            MultiLayerPerceptron net = config.createNetwork();
            MomentumBackpropagation rule = config.createMomentumRule();
            net.setLearningRule(rule);

            System.out.println("Momentumlu BP ile egitim basliyor...");
            net.learn(trainSet);
            System.out.println("Egitim bitti.");

            double trainMseNorm = calculateMSE(net, trainSet);
            double testMseNorm  = calculateMSE(net, testSet);

            double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
            double testMse  = testMseNorm * DataLoader.OUTPUT_SCALE;

            System.out.println("=== SONUÇ (Momentumlu) ===");
            System.out.println("Egitim MSE (gercek ölçek) : " + String.format("%.2f", trainMse));
            System.out.println("Test   MSE (gercek ölçek) : " + String.format("%.2f", testMse));
            System.out.println("==========================");

        } catch (Exception e) {
            System.err.println("Momentumlu egitimde hata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Menü 2: Ağı Eğit ve Test Et (Momentumsuz)
     */
    public void trainAndTestWithoutMomentum() {
        try {
            SplitData split = DataLoader.loadAndSplit(0.75);
            DataSet trainSet = split.trainSet;
            DataSet testSet  = split.testSet;

            System.out.println("Train satir sayisi: " + trainSet.size());
            System.out.println("Test  satir sayisi: " + testSet.size());

            MultiLayerPerceptron net = config.createNetwork();
            BackPropagation rule = config.createNonMomentumRule();
            net.setLearningRule(rule);

            System.out.println("Momentumsuz BP ile egitim basliyor...");
            net.learn(trainSet);
            System.out.println("Egitim bitti.");

            double trainMseNorm = calculateMSE(net, trainSet);
            double testMseNorm  = calculateMSE(net, testSet);

            double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
            double testMse  = testMseNorm * DataLoader.OUTPUT_SCALE;

            System.out.println("=== SONUÇ (Momentumsuz) ===");
            System.out.println("Egitim MSE (gercek ölçek) : " + String.format("%.2f", trainMse));
            System.out.println("Test   MSE (gercek ölçek) : " + String.format("%.2f", testMse));
            System.out.println("===========================");

        } catch (Exception e) {
            System.err.println("Momentumsuz egitimde hata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Menü 3: Ağı Eğit Epoch Göster
     */
    public void trainWithEpochDisplay() {
        try {
            SplitData split = DataLoader.loadAndSplit(0.75);
            DataSet trainSet = split.trainSet;
            DataSet testSet  = split.testSet;

            System.out.println("Train satir sayisi: " + trainSet.size());
            System.out.println("Test  satir sayisi: " + testSet.size());

            MultiLayerPerceptron net = config.createNetwork();
            BackPropagation rule = config.createNonMomentumRule();
            net.setLearningRule(rule);

            int maxEpochs = 500;

            System.out.println("Epoch epoch egitim basliyor (Toplam epoch: " + maxEpochs + ")...");

            for (int epoch = 1; epoch <= maxEpochs; epoch++) {
                rule.doOneLearningIteration(trainSet);

                double trainMseNorm = calculateMSE(net, trainSet);
                double testMseNorm  = calculateMSE(net, testSet);

                double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
                double testMse  = testMseNorm * DataLoader.OUTPUT_SCALE;

                System.out.printf("Epoch %3d -> Train MSE: %.2f | Test MSE: %.2f%n",
                        epoch, trainMse, testMse);
            }

            System.out.println("Epoch bazli egitim tamamlandi.");

        } catch (Exception e) {
            System.err.println("Epoch bazli egitimde hata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Menü 4: Ağı Eğit ve Tekli Test (Momentumlu)
     */
    public void trainAndSingleTestWithMomentum() {
        try {
            SplitData split = DataLoader.loadAndSplit(0.75);
            DataSet trainSet = split.trainSet;

            MultiLayerPerceptron net = config.createNetwork();
            MomentumBackpropagation rule = config.createMomentumRule();
            net.setLearningRule(rule);

            System.out.println("Momentumlu BP ile egitim basliyor (Tekli test modu icin)...");
            net.learn(trainSet);
            System.out.println("Egitim bitti.");

            Scanner scanner = new Scanner(System.in);
            System.out.println("Tekli test icin girdileri giriniz:");

            // SAYFA SAYISI
            System.out.printf("Sayfa sayisi (50 - %.0f): ", DataLoader.MAX_SAYFA);
            String sayfaStr = scanner.nextLine();
            double sayfa;
            try {
                sayfa = Double.parseDouble(sayfaStr);
                if (sayfa < 0) {
                    System.out.println("❌ Geçersiz input: Sayfa sayisi negatif olamaz.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Geçersiz input: Sayısal değer giriniz.");
                return;
            }

            boolean sayfaOutOfRange = (sayfa < 50 || sayfa > DataLoader.MAX_SAYFA);
            if (sayfaOutOfRange) {
                System.out.println("⚠ UYARI: Sayfa sayisi modelin eğitim aralığından farklı.");
            }

            // YAZAR YAŞI
            System.out.printf("Yazar yasi (20 - 80): ");
            String yasStr = scanner.nextLine();
            double yas;
            try {
                yas = Double.parseDouble(yasStr);
                if (yas < 0) {
                    System.out.println("❌ Geçersiz input: Yazar yasi negatif olamaz.");
                    return;
                }
                if (yas > DataLoader.MAX_YAS) {
                    System.out.printf("❌ HATA: Yazar yasi en fazla %.0f olabilir.%n", DataLoader.MAX_YAS);
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Geçersiz input: Sayısal değer giriniz.");
                return;
            }

            boolean yasOutOfRange = (yas < 20 || yas > 80);
            if (yasOutOfRange) {
                System.out.println("⚠ UYARI: Yazar yaşı ideal eğitim aralığının (20-80) dışında.");
            }

            // REKLAM HARCAMASI
            System.out.printf("Reklam harcamasi (bin TL) (0 - %.0f): ", DataLoader.MAX_REKLAM);
            String reklamStr = scanner.nextLine();
            double reklam;
            try {
                reklam = Double.parseDouble(reklamStr);
                if (reklam < 0) {
                    System.out.println("❌ Geçersiz input: Reklam harcamasi negatif olamaz.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Geçersiz input: Sayısal değer giriniz.");
                return;
            }

            boolean reklamOutOfRange = (reklam > DataLoader.MAX_REKLAM);
            if (reklamOutOfRange) {
                System.out.println("⚠ UYARI: Reklam harcaması modelin sınırlarının üzerinde.");
            }

            // NORMALİZASYON
            double normSayfa  = sayfa / DataLoader.MAX_SAYFA;
            double normYas    = yas   / DataLoader.MAX_YAS;
            double normReklam = reklam / DataLoader.MAX_REKLAM;

            // Clamp
            if (normSayfa > 1.0)   normSayfa = 1.0;
            if (normYas > 1.0)     normYas = 1.0;
            if (normReklam > 1.0)  normReklam = 1.0;
            if (normSayfa < 0.0)   normSayfa = 0.0;
            if (normYas < 0.0)     normYas = 0.0;
            if (normReklam < 0.0)  normReklam = 0.0;

            double[] input = new double[]{ normSayfa, normYas, normReklam };

            net.setInput(input);
            net.calculate();
            double[] output = net.getOutput();

            double tahminNorm   = output[0];
            double tahminGercek = tahminNorm * DataLoader.OUTPUT_SCALE;
            long tahminTamSayi  = Math.round(tahminGercek);

            System.out.println("------------------------------------");
            System.out.println("Girilen ham degerler:");
            System.out.println("Sayfa: " + sayfa + ", Yas: " + yas + ", Reklam: " + reklam);
            System.out.println("Aga giren (normalize) degerler:");
            System.out.printf("Sayfa: %.4f, Yas: %.4f, Reklam: %.4f%n", normSayfa, normYas, normReklam);
            System.out.println("------------------------------------");
            System.out.println("TAHMINI SATILAN KITAP: " + tahminTamSayi);
            
            if (sayfaOutOfRange || yasOutOfRange || reklamOutOfRange) {
                System.out.println("Not: Girdiler egitim araligi disinda oldugu icin sapma olabilir.");
            }
            System.out.println("------------------------------------");

        } catch (Exception e) {
            System.err.println("Tekli test modunda hata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Menü 5: K-Fold Test
     */
    public void kFoldTest(int k) {
        if (k < 2) {
            System.out.println("K degeri en az 2 olmalidir.");
            return;
        }

        try {
            DataSet fullData = DataLoader.loadAllDataSet();
            int total = fullData.size();

            if (k > total) {
                System.out.println("K degeri veri sayisindan buyuk olamaz! (Toplam: " + total + ")");
                return;
            }

            System.out.println("Toplam veri sayisi: " + total);
            System.out.println(k + "-Fold cross validation basliyor...");

            int foldSize = total / k;

            double trainMseSumNorm = 0.0;
            double testMseSumNorm  = 0.0;

            for (int fold = 0; fold < k; fold++) {

                int start = fold * foldSize;
                int end   = (fold == k - 1) ? total : start + foldSize;

                DataSet trainSet = new DataSet(DataLoader.INPUT_SIZE, DataLoader.OUTPUT_SIZE);
                DataSet testSet  = new DataSet(DataLoader.INPUT_SIZE, DataLoader.OUTPUT_SIZE);

                for (int i = 0; i < total; i++) {
                    DataSetRow row = fullData.getRowAt(i);

                    if (i >= start && i < end) {
                        testSet.add(row);
                    } else {
                        trainSet.add(row);
                    }
                }

                MultiLayerPerceptron net = config.createNetwork();
                BackPropagation rule = config.createNonMomentumRule();
                net.setLearningRule(rule);

                net.learn(trainSet);

                double trainMseNorm = calculateMSE(net, trainSet);
                double testMseNorm  = calculateMSE(net, testSet);

                trainMseSumNorm += trainMseNorm;
                testMseSumNorm  += testMseNorm;

                double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
                double testMse  = testMseNorm * DataLoader.OUTPUT_SCALE;

                System.out.printf("Fold %2d -> Train MSE: %.2f | Test MSE: %.2f%n",
                        (fold + 1), trainMse, testMse);
            }

            double avgTrainMseNorm = trainMseSumNorm / k;
            double avgTestMseNorm  = testMseSumNorm / k;

            double avgTrainMse = avgTrainMseNorm * DataLoader.OUTPUT_SCALE;
            double avgTestMse  = avgTestMseNorm * DataLoader.OUTPUT_SCALE;

            System.out.println("====================================");
            System.out.println("K-Fold Sonuclari (k = " + k + ")");
            System.out.println("Ortalama Train MSE (gercek ölçek) : " + String.format("%.2f", avgTrainMse));
            System.out.println("Ortalama Test  MSE (gercek ölçek) : " + String.format("%.2f", avgTestMse));
            System.out.println("====================================");

        } catch (IOException e) {
            System.err.println("K-Fold icin veri okunurken hata: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("K-Fold testte hata: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Menü 6: 3-5-1 Topolojisi ile Eğit ve Test Et (Epoch Bazlı)
     */
    public void trainWith351Topology() {
        try {
            SplitData split = DataLoader.loadAndSplit(0.75);
            DataSet trainSet = split.trainSet;
            DataSet testSet  = split.testSet;

            System.out.println("Train satir sayisi: " + trainSet.size());
            System.out.println("Test  satir sayisi: " + testSet.size());
            System.out.println("\n3-5-1 TOPOLOJISI ILE EGITIM BASLIYOR...\n");

            // 3-5-1 topolojisi ile ağ oluştur
            int[] topology = {3, 5, 1};
            MultiLayerPerceptron net = new MultiLayerPerceptron(topology);
            
            BackPropagation rule = new BackPropagation();
            rule.setLearningRate(0.01);
            rule.setMaxIterations(1); // Epoch bazlı kontrol için
            net.setLearningRule(rule);

            int maxEpochs = 500;

            System.out.println("Topoloji: 3-5-1");
            System.out.println("Learning Rate: 0.01");
            System.out.println("Max Epochs: " + maxEpochs);
            System.out.println("Egitim basliyor...\n");

            // Epoch bazlı eğitim
            for (int epoch = 1; epoch <= maxEpochs; epoch++) {
                rule.doOneLearningIteration(trainSet);

                // Her 50 epoch'ta veya ilk epoch'ta göster
                if (epoch % 50 == 0 || epoch == 1) {
                    double trainMseNorm = calculateMSE(net, trainSet);
                    double testMseNorm  = calculateMSE(net, testSet);

                    double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
                    double testMse  = testMseNorm * DataLoader.OUTPUT_SCALE;

                    System.out.printf("Epoch %3d -> Train MSE: %.2f | Test MSE: %.2f%n",
                            epoch, trainMse, testMse);
                }
            }

            System.out.println("\nEgitim bitti.\n");

            // Final MSE hesaplama
            double trainMseNorm = calculateMSE(net, trainSet);
            double testMseNorm  = calculateMSE(net, testSet);

            double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
            double testMse  = testMseNorm * DataLoader.OUTPUT_SCALE;

            System.out.println("================================================");
            System.out.println("           SONUÇ (3-5-1 Topoloji - 500 Epoch)");
            System.out.println("================================================");
            System.out.println("Topoloji                       : 3-5-1");
            System.out.println("Toplam Epoch                   : " + maxEpochs);
            System.out.println("Egitim MSE (gercek ölçek)      : " + String.format("%.2f", trainMse));
            System.out.println("Test   MSE (gercek ölçek)      : " + String.format("%.2f", testMse));
            System.out.println("================================================");

            // Performans değerlendirmesi
            System.out.println("\n📊 PERFORMANS DEĞERLENDİRMESİ:");
            if (testMse < 1500) {
                System.out.println("✅ ÇOK İYİ - Test MSE hedef aralıkta!");
            } else if (testMse < 2000) {
                System.out.println("⚠ İYİ - Test MSE kabul edilebilir seviyede.");
            } else {
                System.out.println("❌ ZAYIF - Test MSE yüksek, model iyileştirmesi gerekebilir.");
            }

            double mseGap = testMse - trainMse;
            if (mseGap < 100) {
                System.out.println("✅ Overfitting yok - Train ve Test MSE yakın.");
            } else if (mseGap < 200) {
                System.out.println("⚠ Hafif overfitting - Train ve Test MSE arasında fark var.");
            } else {
                System.out.println("❌ Overfitting var - Model eğitim setine aşırı uyum sağlamış.");
            }

        } catch (Exception e) {
            System.err.println("3-5-1 topoloji egitiminde hata: " + e.getMessage());
            e.printStackTrace();
        }
    }
}