package com.ysa.main;

import com.ysa.model.NetworkTopology;
import com.ysa.model.NeuralNetworkConfig;
import com.ysa.util.DataLoader;
import com.ysa.util.DataLoader.SplitData;

import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.BackPropagation;

public class TopologyExperimentMain {

    // NetworkTrainer ile aynı MSE hesabı (normalize çıktı üzerinden)
    private static double calculateMSE(MultiLayerPerceptron net, DataSet dataSet) {
        double sum = 0.0;
        int count = 0;

        for (DataSetRow row : dataSet.getRows()) {
            net.setInput(row.getInput());
            net.calculate();

            double[] output = net.getOutput();
            double[] target = row.getDesiredOutput();

            for (int i = 0; i < output.length; i++) {
                double diff = target[i] - output[i];
                sum += diff * diff;
                count++;
            }
        }
        return sum / count;
    }

    private static String hiddenToString(int[] h) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < h.length; i++) {
            sb.append(h[i]);
            if (i < h.length - 1) sb.append("-");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        try {
            // aynı şekilde split
            SplitData split = DataLoader.loadAndSplit(0.75);
            DataSet trainSet = split.trainSet;
            DataSet testSet  = split.testSet;

            NeuralNetworkConfig config = new NeuralNetworkConfig();

            // İstersen epoch çıktısı gibi olsun diye:
            int maxEpochs = 500;

            for (NetworkTopology topo : NetworkTopology.values()) {

                // 1) bu topolojiyi config'e uygula (NeuralNetworkConfig'e dokunmuyoruz!)
                config.setHiddenLayers(topo.hidden());

                // 2) ağı üret
                MultiLayerPerceptron net = config.createNetwork();

                // 3) epoch bazlı eğitim (senin screenshot'a benzer)
                BackPropagation rule = config.createNonMomentumRule();
                rule.setLearningRate(0.01);
                rule.setMaxIterations(1);   // tek iterasyon -> epoch kontrolü
                net.setLearningRule(rule);

                System.out.println("================================");
                System.out.println("TOPOLOJI: 3-" + hiddenToString(topo.hidden()) + "-1");
                System.out.println("================================");

                for (int epoch = 1; epoch <= maxEpochs; epoch++) {
                    rule.doOneLearningIteration(trainSet);

                    if (epoch == 1 || epoch % 50 == 0) {
                        double trainMseNorm = calculateMSE(net, trainSet);
                        double testMseNorm  = calculateMSE(net, testSet);

                        // Not: MSE kareli olduğu için gerçek ölçek dönüşümü OUTPUT_SCALE^2 olmalı.
                        // Senin trainer'da OUTPUT_SCALE ile çarpıyorsun; aynı kalsın istiyorsan aşağıyı bozma.
                        double trainMse = trainMseNorm * DataLoader.OUTPUT_SCALE;
                        double testMse  = testMseNorm  * DataLoader.OUTPUT_SCALE;

                        System.out.printf("Epoch %3d -> Train MSE: %.2f | Test MSE: %.2f%n",
                                epoch, trainMse, testMse);
                    }
                }

                double finalTrainNorm = calculateMSE(net, trainSet);
                double finalTestNorm  = calculateMSE(net, testSet);

                double finalTrain = finalTrainNorm * DataLoader.OUTPUT_SCALE;
                double finalTest  = finalTestNorm  * DataLoader.OUTPUT_SCALE;

                System.out.printf("FINAL -> Train MSE: %.2f | Test MSE: %.2f%n%n",
                        finalTrain, finalTest);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
	