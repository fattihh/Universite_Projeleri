package com.ysa.main;

import java.util.Scanner;
import com.ysa.training.NetworkTrainer;

public class MainApp {

    public static void main(String[] args) {
        NetworkTrainer trainer = new NetworkTrainer();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n╔════════════════════════════════════════════════╗");
            System.out.println("║     YAPAY SİNİR AĞLARI - ANA MENÜ             ║");
            System.out.println("╚════════════════════════════════════════════════╝");
            System.out.println("1. Ağı Eğit ve Test Et (Momentumlu)");
            System.out.println("2. Ağı Eğit ve Test Et (Momentumsuz)");
            System.out.println("3. Ağı Eğit Epoch Göster");
            System.out.println("4. Ağı Eğit ve Tekli Test (Momentumlu)");
            System.out.println("5. K-Fold Cross Validation");
            System.out.println("6. 3-5-1 Topolojisi ile Eğit ve Test Et");
            System.out.println("0. Çıkış");
            System.out.println("════════════════════════════════════════════════");
            System.out.print("Seçiminiz: ");

            String input = scanner.nextLine().trim();
            
            if (input.isEmpty()) {
                System.out.println("⚠ Lütfen bir seçenek giriniz!");
                continue;
            }

            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("❌ Geçersiz giriş! Lütfen bir sayı giriniz.");
                continue;
            }

            System.out.println();

            switch (choice) {
                case 1:
                    System.out.println(">>> Ağı Eğit ve Test Et (Momentumlu) <<<");
                    trainer.trainAndTestWithMomentum();
                    break;

                case 2:
                    System.out.println(">>> Ağı Eğit ve Test Et (Momentumsuz) <<<");
                    trainer.trainAndTestWithoutMomentum();
                    break;

                case 3:
                    System.out.println(">>> Ağı Eğit Epoch Göster <<<");
                    trainer.trainWithEpochDisplay();
                    break;

                case 4:
                    System.out.println(">>> Ağı Eğit ve Tekli Test (Momentumlu) <<<");
                    trainer.trainAndSingleTestWithMomentum();
                    break;

                case 5:
                    System.out.print("K değerini giriniz (örn: 5, 10): ");
                    String kInput = scanner.nextLine().trim();
                    try {
                        int k = Integer.parseInt(kInput);
                        System.out.println(">>> K-Fold Cross Validation (k=" + k + ") <<<");
                        trainer.kFoldTest(k);
                    } catch (NumberFormatException e) {
                        System.out.println("❌ Geçersiz K değeri!");
                    }
                    break;

                case 6:
                    System.out.println(">>> 3-5-1 Topolojisi ile Eğit ve Test Et <<<");
                    trainer.trainWith351Topology();
                    break;

                case 0:
                    System.out.println("Programdan çıkılıyor...");
                    scanner.close();
                    return;

                default:
                    System.out.println("❌ Geçersiz seçim! Lütfen 0-6 arasında bir değer giriniz.");
            }

            // Her işlem sonrası bekleme
            System.out.println("\nDevam etmek için Enter'a basın...");
            scanner.nextLine();
        }
    }
}