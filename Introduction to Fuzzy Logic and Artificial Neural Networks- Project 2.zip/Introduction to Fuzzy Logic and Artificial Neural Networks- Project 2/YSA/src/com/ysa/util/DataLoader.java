package com.ysa.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;

public class DataLoader {

    private static final String CSV_PATH = "data/dataset.csv";

    public static final int INPUT_SIZE  = 3;
    public static final int OUTPUT_SIZE = 1;

    //NORMALİZASYON SABİTLERİ
    public static final double MAX_SAYFA  = 600.0;
    public static final double MAX_YAS    = 100.0;
    public static final double MAX_REKLAM = 800.0;
    public static final double OUTPUT_SCALE = 100000.0;

    /**
     * Veriyi yükler, train/test olarak böl
     */
    public static SplitData loadAndSplit(double trainRatio) throws IOException {
        List<DataSetRow> rows = loadAllRows();
        Collections.shuffle(rows, new Random());

        int trainCount = (int) (rows.size() * trainRatio);

        DataSet trainSet = new DataSet(INPUT_SIZE, OUTPUT_SIZE);
        DataSet testSet  = new DataSet(INPUT_SIZE, OUTPUT_SIZE);

        for (int i = 0; i < rows.size(); i++) {
            if (i < trainCount) {
                trainSet.add(rows.get(i));
            } else {
                testSet.add(rows.get(i));
            }
        }

        SplitData split = new SplitData();
        split.trainSet = trainSet;
        split.testSet  = testSet;
        return split;
    }

    /**
     * Tüm veriyi tek DataSet olarak yükle
     */
    public static DataSet loadAllDataSet() throws IOException {
        List<DataSetRow> rows = loadAllRows();
        DataSet dataSet = new DataSet(INPUT_SIZE, OUTPUT_SIZE);
        for (DataSetRow row : rows) {
            dataSet.add(row);
        }
        return dataSet;
    }

    /**
     * CSV'den tüm satırları okur ve normalize edilmiş DataSetRow listesi döner
     */
    private static List<DataSetRow> loadAllRows() throws IOException {
        List<DataSetRow> rows = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(CSV_PATH))) {
            String line = br.readLine(); // Header'ı atla

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\s*[;,]\\s*");
                if (parts.length < INPUT_SIZE + OUTPUT_SIZE) continue;

                try {
                    double[] input = new double[INPUT_SIZE];

                    // Ham verileri okuyup normalize ediyoruz
                    double rawSayfa  = Double.parseDouble(parts[0]);
                    double rawYas    = Double.parseDouble(parts[1]);
                    double rawReklam = Double.parseDouble(parts[2]);

                    input[0] = rawSayfa / MAX_SAYFA;
                    input[1] = rawYas / MAX_YAS;
                    input[2] = rawReklam / MAX_REKLAM;

                    // Çıkış normalizasyonu
                    double[] output = new double[OUTPUT_SIZE];
                    for (int j = 0; j < OUTPUT_SIZE; j++) {
                        double rawOut = Double.parseDouble(parts[INPUT_SIZE + j]);
                        output[j] = rawOut / OUTPUT_SCALE;
                    }

                    rows.add(new DataSetRow(input, output));

                } catch (NumberFormatException ex) {
                    // Geçersiz satırları atla
                    continue;
                }
            }
        }

        return rows;
    }

    /**
     * Train ve Test DataSet'lerini tutan yardımcı sınıf
     */
    public static class SplitData {
        public DataSet trainSet;
        public DataSet testSet;
    }
}