package com.ysa.model;

import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.BackPropagation;
import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.util.TransferFunctionType;

import com.ysa.util.DataLoader;

public class NeuralNetworkConfig {

    // Şimdilik 3-10-1 topoloji kullanıyoruz.
    // (10 farklı ağı denerken buradaki gizli katman sayısını değiştireceğiz)
    private int[] hiddenLayers = {10};

    public MultiLayerPerceptron createNetwork() {
        int inputSize = DataLoader.INPUT_SIZE;
        int outputSize = DataLoader.OUTPUT_SIZE;

        int[] layerSizes = new int[hiddenLayers.length + 2];
        layerSizes[0] = inputSize;
        for (int i = 0; i < hiddenLayers.length; i++) {
            layerSizes[i + 1] = hiddenLayers[i];
        }
        layerSizes[layerSizes.length - 1] = outputSize;

        // Sigmoid transfer fonksiyonu ile MLP
        return new MultiLayerPerceptron(TransferFunctionType.SIGMOID, layerSizes);
    }

    public MomentumBackpropagation createMomentumRule() {
        MomentumBackpropagation rule = new MomentumBackpropagation();
        rule.setLearningRate(0.01);
        rule.setMomentum(0.7);
        rule.setMaxIterations(200);  // istersen sonra artır
        return rule;
    }

    public BackPropagation createNonMomentumRule() {
        BackPropagation rule = new BackPropagation();
        rule.setLearningRate(0.01);
        rule.setMaxIterations(200);
        return rule;
    }

    // İleride 10 farklı topoloji denerken, bu metodu kullanacağız
    public void setHiddenLayers(int... hidden) {
        this.hiddenLayers = hidden;
    }
}