package com.ysa.model;

public enum NetworkTopology {

    TOPO_1_3_5_1          (5),
    TOPO_2_3_10_1         (10),
    TOPO_3_3_15_1         (15),
    TOPO_4_3_20_1         (20),

    TOPO_5_3_8_5_1        (8, 5),
    TOPO_6_3_10_5_1       (10, 5),
    TOPO_7_3_15_8_1       (15, 8),
    TOPO_8_3_20_10_1      (20, 10),

    TOPO_9_3_12_8_4_1     (12, 8, 4),
    TOPO_10_3_16_12_8_1   (16, 12, 8);

    private final int[] hiddenLayers;

    NetworkTopology(int... hiddenLayers) {
        this.hiddenLayers = hiddenLayers;
    }

    public int[] hidden() {
        return hiddenLayers;
    }

    public String readable() {
        return name()
                .replace("TOPO_", "")
                .replace("_", "-");
    }
}
