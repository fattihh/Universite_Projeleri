package com.ysa.datagenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;
import java.util.Random;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import net.sourceforge.jFuzzyLogic.rule.Variable;

public class DataSetGenerator {

    public static void main(String[] args) {

       
        String fclPath = "fcl/kitap_satis.fcl";

        
        System.out.println("FCL path: " + new File(fclPath).getAbsolutePath());

        FIS fis = FIS.load(fclPath, true);
        if (fis == null) {
            System.err.println("FCL dosyasi yuklenemedi: " + fclPath);
            return;
        }

        FunctionBlock fb = fis.getFunctionBlock("kitap_satis");
        if (fb == null) {
            System.err.println("FunctionBlock bulunamadi: kitap_satis (FCL içindeki FUNCTION_BLOCK adını kontrol et)");
            return;
        }

        Variable satilanKitap = fb.getVariable("satilan_kitap");
        if (satilanKitap == null) {
            System.err.println("Cikti degiskeni bulunamadi: satilan_kitap (FCL içindeki çıktı değişken adını kontrol et)");
            return;
        }

        String folderPath = "data";
        String csvPath = folderPath + File.separator + "dataset.csv";

        File folder = new File(folderPath);
        if (!folder.exists()) folder.mkdirs();

        Random rnd = new Random(42);
        int rowCount = 4000;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvPath))) {

            writer.write("sayfa_sayisi,yazar_yasi,reklam_harcamasi,satilan_kitap");
            writer.newLine();

            Locale locale = Locale.US;

            for (int i = 0; i < rowCount; i++) {

                double sayfa = Math.round(50 + rnd.nextDouble() * 550);
                double yas = Math.round(20 + rnd.nextDouble() * 60);
                double reklam = Math.round(rnd.nextDouble() * 800);

                fis.setVariable("sayfa_sayisi", sayfa);
                fis.setVariable("yazar_yasi", yas);
                fis.setVariable("reklam_harcamasi", reklam);

                fis.evaluate();

                double sonuc = satilanKitap.getValue();

                String line = String.format(locale, "%.0f,%.0f,%.0f,%.2f",
                        sayfa, yas, reklam, sonuc);

                writer.write(line);
                writer.newLine();
            }

            System.out.println("Veri seti olusturuldu: " + csvPath);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
