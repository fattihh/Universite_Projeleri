import csv
import json
import time
from kafka import KafkaProducer

TOPIC_NAME = "spotify_charts"
CSV_PATH = "data/charts.csv"

def create_producer():
    producer = KafkaProducer(
        bootstrap_servers="localhost:9092",
        value_serializer=lambda v: json.dumps(v).encode("utf-8")
    )
    return producer

def stream_csv_to_kafka(limit=None, sleep_sec=0.01):
    """
    charts.csv dosyasını satır satır okuyup Kafka'ya gönderir.
    limit: Kaç satır göndereceğini sınırlandırmak için (None = hepsi)
    sleep_sec: Her satır arasında bekleme (stream simülasyonu)
    """
    producer = create_producer()
    sent = 0

    with open(CSV_PATH, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # İlgili alanları seçiyoruz (gerekirse daraltılabilir)
            message = {
                "title": row.get("title"),
                "artist": row.get("artist"),
                "region": row.get("region"),
                "date": row.get("date"),
                "rank": row.get("rank"),
                "streams": row.get("streams"),
                "chart": row.get("chart"),
                "trend": row.get("trend"),
            }

            producer.send(TOPIC_NAME, message)
            sent += 1

            if sent % 1000 == 0:
                producer.flush()
                print(f"{sent} kayıt Kafka'ya gönderildi...")

            if limit is not None and sent >= limit:
                break

            # Stream havası vermek için biraz yavaşlat
            time.sleep(sleep_sec)

    producer.flush()
    producer.close()
    print(f"✅ Toplam {sent} kayıt Kafka'ya gönderildi.")

if __name__ == "__main__":
    # Örnek: 50.000 kayıt gönder, her satır arası 0.01 sn bekle
    stream_csv_to_kafka(limit=50000, sleep_sec=0.01)
