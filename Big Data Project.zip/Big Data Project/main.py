#venv\Scripts\activate
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    to_date,
    year,
    month,
    sum as spark_sum,
    desc,
)
from pymongo import MongoClient


def create_spark_session():
    """
    SparkSession oluşturur:
    - Doğru Python interpreter'ını kullanır
    - Windows localhost ayarlarını yapar
    """
    current_python = sys.executable
    os.environ["PYSPARK_PYTHON"] = current_python
    os.environ["PYSPARK_DRIVER_PYTHON"] = current_python

    spark = (
        SparkSession.builder
        .appName("SpotifyChartsBigData")
        .master("local[*]")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .config("spark.driver.host", "127.0.0.1")
        .getOrCreate()
    )
    return spark


def write_df_to_mongo(df, db, collection_name):
    """
    Küçük boyutlu Spark DataFrame'lerini (aggregation sonuçları gibi)
    pandas'a çevirip MongoDB'ye yazar.
    """
    records = df.toPandas().to_dict("records")
    collection = db[collection_name]
    # eski verileri sil, taze veri yaz
    collection.delete_many({})
    if records:
        collection.insert_many(records)
    print(f"✅ MongoDB -> {collection_name} koleksiyonuna {len(records)} doküman yazıldı.")


def main():
    # 1) Spark
    spark = create_spark_session()

    # 2) CSV'den veri oku
    file_path = "data/charts.csv"
    print(f"📌 CSV okunuyor: {file_path}")

    df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .csv(file_path)
    )

    print("📌 Ham şema:")
    df.printSchema()

    # 3) Tip dönüşümleri
    df_clean = (
        df
        .withColumn("rank", col("rank").cast("int"))
        .withColumn("streams", col("streams").cast("long"))
        .withColumn("date", to_date(col("date"), "yyyy-MM-dd"))
    )

    df_clean = df_clean.filter(
        col("rank").isNotNull() &
        col("streams").isNotNull() &
        col("date").isNotNull()
    )

    # 4) Ek kolonlar
    df_enriched = (
        df_clean
        .withColumn("year", year(col("date")))
        .withColumn("month", month(col("date")))
    )

    print("📌 Temiz + zenginleştirilmiş şema:")
    df_enriched.printSchema()

    total_rows = df_enriched.count()
    print(f"📌 Temiz kayıt sayısı: {total_rows}")

    # 5) Analiz DataFrame'leri

    # 5.1) Bölge bazlı toplam stream
    df_region_streams = (
        df_enriched
        .groupBy("region")
        .agg(spark_sum("streams").alias("total_streams"))
        .orderBy(desc("total_streams"))
    )

    print("📌 Örnek bölge bazlı toplam stream:")
    df_region_streams.show(10)

    # 5.2) Global en çok stream alan ilk 100 şarkı
    df_top_songs = (
        df_enriched
        .groupBy("title", "artist")
        .agg(spark_sum("streams").alias("total_streams"))
        .orderBy(desc("total_streams"))
        .limit(100)
    )

    print("📌 Örnek en çok dinlenen şarkılar:")
    df_top_songs.show(10, truncate=False)

    # 5.3) Yıllara göre toplam stream
    df_year_streams = (
        df_enriched
        .groupBy("year")
        .agg(spark_sum("streams").alias("total_streams"))
        .orderBy("year")
    )

    print("📌 Yıllara göre toplam stream:")
    df_year_streams.show()

    # 6) MongoDB bağlantısı (PyMongo)
    mongo_uri = "mongodb://localhost:27017"
    client = MongoClient(mongo_uri)
    db = client["spotify_db"]

    # 7) DataFrame'leri MongoDB'ye yaz
    write_df_to_mongo(df_region_streams, db, "region_streams")
    write_df_to_mongo(df_top_songs, db, "top_songs")
    write_df_to_mongo(df_year_streams, db, "year_streams")

    print("🎯 Tüm aggregation sonuçları MongoDB'de hazır.")
    spark.stop()
    client.close()


if __name__ == "__main__":
    main()
