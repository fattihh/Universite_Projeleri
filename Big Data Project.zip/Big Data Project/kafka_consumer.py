import json
from kafka import KafkaConsumer
from pymongo import MongoClient

TOPIC_NAME = "spotify_charts"
MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "spotify_kafka"
COLLECTION_NAME = "stream_events"

def create_mongo_collection():
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    collection = db[COLLECTION_NAME]
    return client, collection

def create_consumer():
    consumer = KafkaConsumer(
        TOPIC_NAME,
        bootstrap_servers="localhost:9092",
        auto_offset_reset="earliest",   # en baştan oku
        enable_auto_commit=True,
        group_id="spotify-consumer-group",
        value_deserializer=lambda m: json.loads(m.decode("utf-8")),
    )
    return consumer

def consume_and_write_to_mongo():
    client, collection = create_mongo_collection()
    consumer = create_consumer()

    print("📥 Kafka'dan mesajlar okunuyor, MongoDB'ye yazılıyor...")
    try:
        for message in consumer:
            data = message.value

            # Gerekirse tip dönüşümü yap:
            try:
                if data.get("streams") is not None:
                    data["streams"] = int(data["streams"])
                if data.get("rank") is not None:
                    data["rank"] = int(data["rank"])
            except ValueError:
                pass  # tip dönüşemeyen varsa olduğu gibi bırak

            collection.insert_one(data)
            print(f"MongoDB'ye kayıt eklendi: {data.get('title')} - {data.get('region')}")

    except KeyboardInterrupt:
        print("⏹ Consumer durduruldu (Ctrl+C).")
    finally:
        consumer.close()
        client.close()

if __name__ == "__main__":
    consume_and_write_to_mongo()
