package uygulama;

import java.util.Scanner;
import java.io.File;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import net.sourceforge.jFuzzyLogic.rule.Variable;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;

public class Main {

    public static void main(String[] args) {

        // 1) FCL dosyasini yukle (paket icinden)
        String fileName = "src/uygulama/kitap_satis.fcl";
        
        // Alternatif yol
        File fclFile = new File(Main.class.getResource("kitap_satis.fcl").getFile());
        
        FIS fis = FIS.load(fileName, true);

        if (fis == null) {
            System.err.println("FCL dosyasi yuklenemedi: " + fileName);
            System.err.println("Lutfen 'kitap_satis.fcl' dosyasinin proje ana dizininde oldugunu kontrol edin.");
            return;
        }

        FunctionBlock fb = fis.getFunctionBlock("kitap_satis");

        // Kullanici girdilerini al
        Scanner scanner = new Scanner(System.in);

        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║     BULANIK MANTIK KITAP SATIS TAHMIN SISTEMI         ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
        System.out.println();
        System.out.println("Bu sistem anket verilerine dayanarak kitap satis tahmini yapar.");
        System.out.println("Not: Reklam harcamasini bin TL cinsinden giriniz");
        System.out.println("     (ornegin 30 = 30.000 TL, 500 = 500.000 TL)");
        System.out.println();
        System.out.println("─────────────────────────────────────────────────────────");
        System.out.println();

        // Sayfa sayisi girisi
        System.out.println("📖 SAYFA SAYISI");
        System.out.println("   Anket bulgulari:");
        System.out.println("   • Kisa kitap: 60-150 sayfa");
        System.out.println("   • Ideal kitap: 250-300 sayfa");
        System.out.println("   • Uzun kitap: 450-500 sayfa");
        System.out.print("   Giriniz (50 - 600): ");
        double sayfa = scanner.nextDouble();

        // Yazar yasi girisi
        System.out.println();
        System.out.println("👤 YAZAR YASI");
        System.out.println("   Anket kategorileri:");
        System.out.println("   • Genc yazar: 25-35 yas");
        System.out.println("   • Orta yasli yazar: 35-50 yas");
        System.out.println("   • Deneyimli yazar: 50+ yas (En cok tercih edilen!)");
        System.out.print("   Giriniz (20 - 80): ");
        double yas = scanner.nextDouble();

        // Reklam harcamasi girisi
        System.out.println();
        System.out.println("💰 REKLAM HARCAMASI (bin TL)");
        System.out.println("   Anket senaryolari:");
        System.out.println("   • Az reklam: 10-20 bin TL");
        System.out.println("   • Orta reklam: 100-200 bin TL");
        System.out.println("   • Yogun reklam: 400-500 bin TL");
        System.out.println("   Not: Cok reklam guven azaltir!");
        System.out.print("   Giriniz (0 - 800): ");
        double reklam = scanner.nextDouble();

        System.out.println();
        System.out.println("─────────────────────────────────────────────────────────");

        // Aralik disi girisler icin uyarilar
        boolean uyariVar = false;
        if (sayfa < 50 || sayfa > 600) {
            System.out.println("⚠️  UYARI: Sayfa sayisi model araligi disinda (50-600).");
            uyariVar = true;
        }
        if (yas < 20 || yas > 80) {
            System.out.println("⚠️  UYARI: Yazar yasi model araligi disinda (20-80).");
            uyariVar = true;
        }
        if (reklam < 0 || reklam > 800) {
            System.out.println("⚠️  UYARI: Reklam harcamasi model araligi disinda (0-800 bin TL).");
            uyariVar = true;
        }
        
        if (uyariVar) {
            System.out.println("─────────────────────────────────────────────────────────");
        }

        // Girdileri bulanik modele set et
        fis.setVariable("sayfa_sayisi", sayfa);
        fis.setVariable("yazar_yasi", yas);
        fis.setVariable("reklam_harcamasi", reklam);

        // Modeli calistir
        fis.evaluate();

        // Cikti degiskenini al
        Variable satilanKitap = fb.getVariable("satilan_kitap");
        double sonuc = satilanKitap.getValue();

        // Sonuclari goster
        System.out.println();
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║                    TAHMIN SONUCU                       ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
        System.out.println();
        System.out.printf("   📊 Tahmini Satilan Kitap Sayisi: %.0f adet%n", sonuc);
        System.out.println();
        
        // Performans kategorisi
        String performans;
        if (sonuc < 5000) {
            performans = "Cok Dusuk / Dusuk";
        } else if (sonuc < 15000) {
            performans = "Orta";
        } else if (sonuc < 40000) {
            performans = "Yuksek";
        } else {
            performans = "Cok Yuksek";
        }
        System.out.println("   📈 Performans Seviyesi: " + performans);
        
        // Anket bulgularina gore oneriler
        System.out.println();
        System.out.println("─────────────────────────────────────────────────────────");
        System.out.println("💡 ANKET BULGULARINA GORE ONERILER:");
        System.out.println();
        
        if (yas < 40) {
            System.out.println("   • Genc yazar algilaniyor - deneyimli yazarlar daha cok");
            System.out.println("     tercih ediliyor.");
        } else if (yas >= 50) {
            System.out.println("   ✓ Deneyimli yazar - en yuksek tercih edilen grup!");
        }
        
        if (sayfa >= 200 && sayfa <= 400) {
            System.out.println("   ✓ Ideal sayfa araligi - en populer aralik!");
        } else if (sayfa < 200) {
            System.out.println("   • Kisa kitap - orta boy kitaplar daha cok tercih ediliyor.");
        } else {
            System.out.println("   • Uzun kitap - okuyucularin cogu 200-400 sayfa arligini");
            System.out.println("     tercih ediyor.");
        }
        
        if (reklam > 300) {
            System.out.println("   ⚠️  Yuksek reklam - cok reklam guven azaltabilir!");
            System.out.println("      Ankette az/orta reklam daha iyi sonuc verdi.");
        } else if (reklam >= 30 && reklam <= 200) {
            System.out.println("   ✓ Optimal reklam seviyesi!");
        }
        
        System.out.println();
        System.out.println("─────────────────────────────────────────────────────────");
        System.out.println();

        // 7) Grafikler
        System.out.println("Grafikler olusturuluyor...");
        System.out.println();
        
        // Tum giris ve cikis degiskenlerinin UF grafikleri:
        JFuzzyChart.get().chart(fb);

        // Sadece cikti degiskeni icin, durulama sonrasi tarali alan grafigi:
        JFuzzyChart.get().chart(satilanKitap, satilanKitap.getDefuzzifier(), true);

        System.out.println("✓ Grafikler ekranda goruntulenebilir.");
        System.out.println();
        System.out.println("════════════════════════════════════════════════════════");
        System.out.println("Program sonlandi. Tesekkurler!");
        
        scanner.close();
    }
}